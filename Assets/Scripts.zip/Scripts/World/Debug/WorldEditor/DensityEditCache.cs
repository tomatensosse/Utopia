public class DensityEditCache
{
   
}